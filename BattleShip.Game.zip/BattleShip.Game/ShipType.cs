﻿namespace BattleShip.Models
{
    internal class ShipType
    {
    }
}