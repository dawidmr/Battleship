﻿using System;

namespace BattleShip.Models
{
    public abstract class Grid
    {
        public int Length { get; } = 10;


    }
}
