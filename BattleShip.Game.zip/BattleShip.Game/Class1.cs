﻿using System;

namespace Battleship.Game
{
    public class Class1
    {
    }
}
