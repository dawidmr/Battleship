﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.Models
{
    public class MainGrid: Grid
    {
        public List<Ship> Ships = new List<Ship>();
    }
}
