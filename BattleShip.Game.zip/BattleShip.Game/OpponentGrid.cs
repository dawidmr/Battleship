﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.Models
{
    public class OpponentGrid
    {
        public List<Square> Attempts = new List<Square>();
    }
}
