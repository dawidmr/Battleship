﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShip.Models
{
    public enum SquareStates
    {
        Virgin,
        Hit,
        Miss
    }
}
